Release Notes for PFC Version 8.0 Message Manager Utility

Copyright � 1996-2000 Sybase, Inc. and its subsidiaries.  All rights reserved.

Updated 10/4/1999



Contents of this file:
=====================
File Descriptions
App library search paths


-----------------------------------------
File Descriptions:
-----------------------------------------
pfcmsg.pbl (Source Code)
pfcmsg.ico (Application icon)
pfcmsg.bmp (Application bitmap)
pfcmsg.ini (Ini file)
pfcmsg.hlp (Help file)
pfcmsg.pbr (Application pbr file for building exe)
Readme.Txt  (This file)
pfcmsg.txt (message table as ships with PFC)
arrowl.ico (used in drag/drop funtionaity)
arrowr.ico (used in drag/drop funtionaity)
stop.bmp (Used in error handler functionality (n_cst_error))
info.bmp (Used in error handler functionality (n_cst_error))
excl.bmp (Used in error handler functionality (n_cst_error))
quest.bmp (Used in error handler functionality (n_cst_error))

-----------------------------------------
Library Search Paths for Message Manager:
-----------------------------------------
pfcmsg.pbl; 
pfcapsrv.pbl; 
pfcdwsrv.pbl; 
pfcmain.pbl; 
pfcwnsrv.pbl; 
pfeapsrv.pbl; 
pfedwsrv.pbl; 
pfemain.pbl; 
pfewnsrv.pbl; 
pfcutil.pbl; 
pfeutil.pbl