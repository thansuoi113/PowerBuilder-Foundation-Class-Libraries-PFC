﻿INSERT INTO examples VALUES (
	3,
	'Error Service Example',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_errormsgservice',
	'');
INSERT INTO examples VALUES (
	4,
	'Split Bar 3 Pane Style',
	'',
	NULL,
	'windowswinntsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_splitbar3panestyle',
	'');
INSERT INTO examples VALUES (
	1,
	'Save Process: All DW Scenarios',
	'',
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_dw3types',
	'');
INSERT INTO examples VALUES (
	23,
	'(5.x) Update a Treeview',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_treeviewupdate',
	NULL);
INSERT INTO examples VALUES (
	24,
	'Recursive Tree View',
	NULL,
	NULL,
	'',
	'enterprisedesktop',
	0,
	'w_treeviewrecursive',
	NULL);
INSERT INTO examples VALUES (
	5,
	'Type Ahead in the DDLB & DDPLB',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_dropdownsearchlb',
	'');
INSERT INTO examples VALUES (
	6,
	'Drop-down Search Service',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_dropdownsearchdw',
	'');
INSERT INTO examples VALUES (
	7,
	'Find and Replace Service',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_findreplacedw',
	'');
INSERT INTO examples VALUES (
	8,
	'Find and Replace in a RTE',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_findreplacerte',
	'');
INSERT INTO examples VALUES (
	27,
	'Status Bar',
	NULL,
	NULL,
	'windowswinnt',
	'enterprisedesktop',
	0,
	'w_statusbarframe',
	'');
INSERT INTO examples VALUES (
	9,
	'Basic Retrieval Arguments',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_linkageretrieve',
	'');
INSERT INTO examples VALUES (
	10,
	'Basic Scrolling',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_linkagescroll',
	'');
INSERT INTO examples VALUES (
	11,
	'Basic Filters',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_linkagefilter',
	'');
INSERT INTO examples VALUES (
	12,
	'Filter Service Dialogs',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_filterdialogs',
	'');
INSERT INTO examples VALUES (
	13,
	'Sort Service Dialogs',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_sort',
	'');
INSERT INTO examples VALUES (
	14,
	'Multiple Table Update',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_multiupdate',
	'');
INSERT INTO examples VALUES (
	15,
	'Print Preview Service',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_dwprintpreview',
	'');
INSERT INTO examples VALUES (
	35,
	'Using Rich Text Edits with Files',
	NULL,
	NULL,
	'',
	'enterprisedesktop',
	0,
	'w_rtewithfiles',
	'');
INSERT INTO examples VALUES (
	17,
	'Row Manager Service',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_rowmanager',
	'');
INSERT INTO examples VALUES (
	18,
	'Row Selection Service',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_rowselection',
	'');
INSERT INTO examples VALUES (
	19,
	'Required Columns Service',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_requiredfields',
	'');
INSERT INTO examples VALUES (
	20,
	'File Services Example',
	'',
	'',
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_fileserv',
	'');
INSERT INTO examples VALUES (
	26,
	'Window Resize Service',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_resizefind',
	'');
INSERT INTO examples VALUES (
	36,
	'Using Rich Text Edits with Your DataBase',
	NULL,
	NULL,
	'',
	'enterprisedesktop',
	0,
	'w_rtefromdbase',
	'');
INSERT INTO examples VALUES (
	1001,
	'[Methods Header Record]',
	NULL,
	NULL,
	'windowswinntmacintoshsol2',
	'enterprisedesktop',
	0,
	NULL,
	NULL);
INSERT INTO examples VALUES (
	38,
	'Retrieval with Auto-updates',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_linkautoupdate',
	'');
INSERT INTO examples VALUES (
	33,
	'Dynamic Filter Expressions',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_buildfilter',
	'');
INSERT INTO examples VALUES (
	0,
	'[Category Header Record]',
	'',
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	NULL,
	'');
INSERT INTO examples VALUES (
	1000,
	'[Major Components Header Record]',
	NULL,
	NULL,
	'windowswinntmacintoshsol2',
	'enterprisedesktop',
	0,
	NULL,
	NULL);
INSERT INTO examples VALUES (
	1002,
	'[Variables Header Record]',
	NULL,
	NULL,
	'windowswinntmacintoshsol2',
	'enterprisedesktop',
	0,
	NULL,
	NULL);
INSERT INTO examples VALUES (
	37,
	'Progress Bar Sampler',
	'',
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_progbarsampler',
	'');
INSERT INTO examples VALUES (
	53,
	'Basic Listview',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_listview6',
	NULL);
INSERT INTO examples VALUES (
	29,
	'Split Bar Explorer Style ',
	'',
	NULL,
	'windowswinntsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_splitbarexplorerstyle',
	NULL);
INSERT INTO examples VALUES (
	30,
	'Resize Dynamic Tab Pages',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_tabresize',
	'');
INSERT INTO examples VALUES (
	44,
	'Resize Freeform DataWindow',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_dwresizeff',
	'');
INSERT INTO examples VALUES (
	45,
	'Resize Grid DataWindow',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_dwresizegrid',
	'');
INSERT INTO examples VALUES (
	47,
	'Weighted Resize of a Window',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_resizedwsyntax',
	NULL);
INSERT INTO examples VALUES (
	49,
	'Basic Treeview',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_treeview6',
	NULL);
INSERT INTO examples VALUES (
	50,
	'Treeview Linked to a Listview',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_treeviewlistview6',
	NULL);
INSERT INTO examples VALUES (
	51,
	'Update a Treeview',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_treeviewupdate6',
	NULL);
INSERT INTO examples VALUES (
	48,
	'A Logical Unit of Work',
	NULL,
	NULL,
	'',
	'enterprisedesktop',
	0,
	'w_luw',
	NULL);
INSERT INTO examples VALUES (
	2,
	'Metaclass Example',
	NULL,
	NULL,
	'',
	'enterprisedesktop',
	0,
	'w_metaclass',
	NULL);
INSERT INTO examples VALUES (
	28,
	'Across Tab Pages',
	'',
	'',
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_tablink',
	'');
INSERT INTO examples VALUES (
	31,
	'Filter Service Settings',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_filtersettings',
	'');
INSERT INTO examples VALUES (
	32,
	'Refresh Drop-down DataWindows',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_refreshdddws',
	'');
INSERT INTO examples VALUES (
	21,
	'(5.x) Basic Tree View',
	NULL,
	NULL,
	'',
	'enterprisedesktop',
	0,
	'w_treeview',
	NULL);
INSERT INTO examples VALUES (
	22,
	'(5.x) Treeview and a Listview',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_treeviewlistview',
	NULL);
INSERT INTO examples VALUES (
	41,
	'Filter with Cascading Deletes',
	'',
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_linkcascadedeletes',
	'');
INSERT INTO examples VALUES (
	39,
	'Filter with Cascading Keys',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_linkcascadekeys',
	'');
INSERT INTO examples VALUES (
	46,
	'DDDW Calculator and Calendar',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_ddcalsamp',
	'');
INSERT INTO examples VALUES (
	16,
	'(5.x) Basic Listview',
	NULL,
	NULL,
	'windowswinntmacintoshsol2aixhpux',
	'enterprisedesktop',
	0,
	'w_listview',
	NULL);
INSERT INTO examples VALUES (
	43,
	'Split Bars within a Window Object',
	'',
	NULL,
	'',
	'enterprisedesktop',
	0,
	'w_splitbarwin',
	'');
INSERT INTO examples VALUES (
	52,
	'Recursive Tree View',
	NULL,
	NULL,
	'',
	'enterprisedesktop',
	0,
	'w_treeviewrecursive6',
	NULL);